//rafc
import React from "react";
import data from "./data.json";
import { ProductList } from "./ProductList";
import { ModalProductDetail } from "./ModalProdctDetail";
// import { ModalProdctDetail } from "./ModalProdctDetail";
import { useSelector, useDispatch } from "react-redux";
import { ModalCart } from "./ModalCart";

export const BTShoe = () => {
  console.log("data: ", data);
  // lay du lieu tu store redux
  const { number } = useSelector((state) => state.btShoeReducer);
  console.log("number: ", number);
  // thay doi du lieu cua store redux
  const dispath = useDispatch(); // dung de gui thong tin (action) len store cua redux => thay doi du lieu cua store
  return (
    <div className="container mt-5">
      <h1>Demo Redux</h1>
      <p>Number: {number}</p>
      <button
        className="btn btn-success"
        onClick={() => {
          dispath({
            type: "INCREAT_NUMBER", // bat buoc
            payload: 1,
          });
        }}
      >
        + Number
      </button>
      <h1 className="mt-3">BTShoe</h1>
      <ProductList data={data} />
      <ModalProductDetail />
      <ModalCart />
    </div>
  );
};
